/*	DAVONG winchester driver for the IBM PC.
*		Version 86/2.0		Dec 22, 1982
*			Edited:	4/27/84
*
*****************************************************************
*								*
*	(C)Copyright by VenturCom, Inc. 1982, 1983, 1984	*
*								*
*	All rights reserved: VENTURCOM INC. 1982,1983,1984	*
*								*
*	This source listing is supplied in accordance with	*
*	the Software Agreement you have with VenturCom and	*
*	the Western Electric Company.				*
*								*
****************************************************************/
#include <sys/param.h>
#include <sys/buf.h>
#include <sys/user.h>
#include <sys/devparm.h>

#define	NDRV	1		/* number of partitions */
#define	IOADD	0x320		/* i/o register file origin */
#define	NHEAD	4		/* number of heads (2, 4, or 6) */
#define	SECHEAD	17		/* sectors per head */
#define	IOINT	5		/* interrupt request number */
#define	PRECOMP	128		/* cylinder for write precomp start */

#define	DMACHAN		3	/* DMA channel number */
#define	DMAPAGE		0x82	/* channel dependent: 1 = 0x83, 3 = 0x82 */
#define	DMAREAD		(0x44+DMACHAN)
#define	DMAWRITE	(0x48+DMACHAN)
#define	DMAADDR		(2*DMACHAN)
#define	DMACOUNT	(DMAADDR+1)

/*
 * Davong controller commands and register file layout.
 */
#define	RESTORE	0x16
#define	SEEK	0x76
#define	READ	0x28
#define	WRITE	0x30

struct davong {
	unsigned char data;
	unsigned char error;
	unsigned char unused;
	unsigned char sector;
	unsigned char cyllow;
	unsigned char cylhi;
	unsigned char select;
	unsigned char cmd;
};

struct xtmsg {			/* convert error numbers to messages */
	char	num;
	char	*msg;
} xtmsg[] = {
	0x80,	"Bad block mark found",
	0x40,	"Data CRC error",
	0x20,	"ID CRC error",
	0x10,	"ID not found",
	0x04,	"Aborted command",
	0x02,	"Track 0 not found",
	0x01,	"Data Address Mark not found",
	0,	"Unknown error",
};

struct {			/* disk partitions */
	unsigned nblock;	/* number of 512 byte blocks */
	unsigned oblock;	/* offset in blocks for first block */
} xt_sizes[8*NDRV] = {
	3730,	0,		/* 1.8mb  2980 root 750 swap	*/
	340,	3730,		/*  .2mb  tmp & pipes		*/
	-1,	4070,		/* what ever is left over	*/
	0,	0,
	0,	0,
	0,	0,
	0,	0,
	-1,	0,		/* complete physical drive */
};

#define	b_cylin	b_resid		/* redefine for readability */

struct	devtab	xttab;
struct buf *xt_bp;		/* temp buf pntr for raw i/o stradling of 64k */
int	xtfirst = 0;		/* first time called */
char	xtec[9];		/* interrupt transfer vector */
int	xtnhead = NHEAD;	/* for benefit of external changes */

xtstrategy(abp) struct buf *abp; {
	register struct buf *bp;
	register unsigned int bn;
	int unit, xtintr();

	if( xtfirst == 0 ){
		xtfirst++;
		setiva( 0x34, &xtintr, xtec);
		/*
		 * Initialize the winchester.
		 */
		io_outb( &IOADD->select, 0);
		io_outb( &IOADD->error, PRECOMP/4);
		io_outb( &IOADD->cmd, RESTORE);
		while( io_inb( &IOADD->cmd) & 0200 )
			;
		/*
		 * Get a buffer for raw i/o which stradles a 64kb boundry.
		 */
		xt_bp = (struct buf *)getblk(NODEV);
	}
	unit = (bp = abp)->b_dev&037;
	bn = bp->b_blkno;
	if(unit>=8*NDRV||(bn+((255-bp->b_wcount)>>8))>xt_sizes[unit].nblock){
		bp->b_flags |= B_ERROR;
		iodone(bp);
		return;
	}
	bn += xt_sizes[unit].oblock;
	bp->b_cylin = bn/(xtnhead*SECHEAD);
	spl5();
	disksort(&xttab, bp);
	if( xttab.d_active==0 )
		xtstart();
	spl0();
}

xtstart() {
	register struct buf *bp;
	register unsigned int bn;
	unsigned int addr;
	struct { char lobyte; char hibyte; };

	if( (bp = xttab.d_actf) == NULL )
		return;
	xttab.d_active++;

	/*
	 * Set up DMA controller.
	 */
	io_outb( 0x0c, 1);		/* Clear first/last FF */
	if( bp->b_flags&B_READ )
		io_outb( 0x0b, DMAREAD);
	else
		io_outb( 0x0b, DMAWRITE);
	addr = bp->b_addr;
	if( bp->b_flags&B_PHYS ){
		/*
		 * Check for stradling of 64kb boundry.
		 */
		if( bp->b_addr > 0xFE00 ){
			if( (bp->b_flags&B_READ) == 0 ){
				bn = spl6();
				addr = u.u_ds;
				u.u_ds = (bp->b_xmem<<12) + 32;
				copyin(bp->b_addr-512, xt_bp->b_addr, 512);
				u.u_ds = addr;
				splx(bn);
			}
			addr = xt_bp->b_addr;
			goto cont;
		}
		io_outb( DMAPAGE, bp->b_xmem);
		io_outb( DMAADDR, bp->b_addr.lobyte);
		io_outb( DMAADDR, bp->b_addr.hibyte);
	} else {
cont:		bn = addr >> 4;
		bn += getds();
		io_outb( DMAPAGE, (unsigned)bn >> 12);
		io_outb( DMAADDR, (bn<<4) + (addr&017));
		io_outb( DMAADDR, bn>>4);
	}
	io_outb( DMACOUNT, 0xff);
	io_outb( DMACOUNT, 0x01);
	io_outb( 0x0a, DMACHAN);

	/*
	 * Set up the Davong controller.
	 */
	bn = bp->b_blkno + xt_sizes[bp->b_dev&037].oblock;
	io_outb( &IOADD->sector, (bn%SECHEAD) + 1);
	io_outb( &IOADD->select, (bn/SECHEAD)%xtnhead);
	io_outb( &IOADD->error, PRECOMP/4);
	bn /= SECHEAD*xtnhead;
	io_outb( &IOADD->cyllow, bn);
	io_outb( &IOADD->cylhi, bn>>8);

	/*
	 * Start the action.
	 */
	io_outb( 0x21, io_inb(0x21)&~(01<<IOINT) );
	if( bp->b_flags&B_READ )
		io_outb( &IOADD->cmd, READ);
	else
		io_outb( &IOADD->cmd, WRITE);
}

xtintr() {
	register struct buf *bp;
	register int i;
	int j, status;

/**	io_outb( 0xa, DMACHAN|04);	**/
	io_outb( 0x21, io_inb(0x21) | (01<<IOINT) );
	io_outb( 0x20, 0x20);
	status = io_inb( &IOADD->cmd);
	if( xttab.d_active!=0 ){
		bp = xttab.d_actf;
		if( (status&01)!=0 ){
			j = io_inb( &IOADD->error);
			for( i = 0; xtmsg[i].num!=0; i++ )
				if( (xtmsg[i].num&j) != 0 )
					break;
			deverror(bp, xtmsg[i].msg, j);
			bp->b_flags  |= B_ERROR;
		} else {
			if( bp->b_flags&B_PHYS ){
				if( bp->b_addr>-512 && (bp->b_flags&B_READ) ){
					i = u.u_ds;
					u.u_ds = (bp->b_xmem<<12) + 32;
					copyout(xt_bp->b_addr, bp->b_addr-512,
						512);
					u.u_ds = i;
				}
				if( (bp->b_wcount += 256) < 0 ){
					if( (bp->b_addr += 512) < 512 )
						bp->b_xmem++;
					bp->b_blkno++;
					goto done;
				}
			}
		}
		xttab.d_active = 0;
		xttab.d_actf = bp->av_forw;
		bp->b_resid = 0;
		iodone(bp);
	}
done:
	io_outb(&IOADD->select,030);
	xtstart();
}

xtread(dev) { aphysio(xtstrategy, dev, B_READ); }

xtwrite(dev) { aphysio(xtstrategy, dev, B_WRITE); }


xtioctl(dev, cmd, addr) char *addr; {
	register int i;
	struct diskparm buf;

	if( cmd == I_GETDPP ){
		if( xtfirst==0 )	/* make sure data is accurate */
			brelse( bread(dev,0) );
		i = dev&037;
		buf.d_nblock = xt_sizes[i].nblock;
		buf.d_offset = xt_sizes[i].oblock;
		buf.d_nsect = SECHEAD;
		buf.d_nhead = xtnhead;
		buf.d_ntrack = 0;		/* don't care */
		if( copyout( &buf, addr, sizeof(buf)) )
			u.u_error = EFAULT;
	} else
		u.u_error = EINVAL;
}
