/*
 * Configuration file to:
 *	1) table entries to device drivers,
 *	2) define root, swap, and pipe devices,
 *	3) allocate space for several adjustable tables,
 *	4) and set several user modifiable parameters.
 *
 *	Version 86/1.1		May 27, 1983
 *		Edited:	11/15/83
 *
 *     (C)Copyright by VenturCom Inc. 1982,1983
 * All rights reserved:	  VENTURCOM INC. 1982,1983
 */
#include <sys/param.h>
#include <sys/proc.h>
#include <sys/conf.h>
#include <sys/text.h>
#include <sys/inode.h>
#include <sys/file.h>
#include <sys/buf.h>
#include <sys/systm.h>
#include <sys/tty.h>

	extern int ttyopen(), ttyread(), ttywrite(), ttyioctl();
	extern int mmread(), mmwrite(), nulldev(), nodev();
	extern int cslopen(), cslclose(), cslread(), cslwrite(), cslioctl();
	extern int flpread(), flpwrite(), flpstrategy(), flptab;
	extern int caopen(), caclose(), caread(), cawrite(), caioctl();
	extern int paopen(), paclose(),  pawrite(), paioctl();
#ifdef	DAVONG
	extern int davread(), davwrite(), davstrategy(), davtab;
#endif
#ifdef	XT
	extern int xtread(), xtwrite(), xtstrategy(), xttab;
#endif
	extern int ioread(),iowrite();
	extern int i3eopen(),i3eread(),i3ewrite(),i3ectl();

/*
 * Block (buffered; mountable) type devices.
 *	OPEN		CLOSE		STRATEGY	TABLE
 */
struct	bdevsw	bdevsw[] = {
	nulldev,	nulldev,	flpstrategy,	&flptab,/* 0 floppy */
#ifdef	XT
	nulldev,	nulldev,	xtstrategy,	&xttab,	/* 1 winnie */
#else
# ifdef	DAVONG
	nulldev,	nulldev,	davstrategy,	&davtab,/* 1 winnie */
# endif
#endif
	0
};

/*
 * Character (terminals and `raw'(unbuffered)) type devices.
 *	OPEN	   CLOSE      READ	 WRITE	    IOCTL
 */
struct	cdevsw	cdevsw[] = {
	ttyopen,   nulldev,   ttyread,   ttywrite,  ttyioctl,	/* 0 tty */
	nulldev,   nulldev,   mmread,    mmwrite,   nodev,	/* 1 null/mem */
	cslopen,   cslclose,  cslread,   cslwrite,  cslioctl,	/* 2 console */
	caopen,    caclose,   caread,    cawrite,   caioctl,	/* 3 comm ad*/
	nulldev,   nulldev,   flpread,   flpwrite,  nodev,	/* 4 floppy */
#ifdef	XT
	nulldev,   nulldev,   xtread,    xtwrite,   nodev,	/* 5 winnie */
#else
# ifdef	DAVONG
	nulldev,   nulldev,   davread,   davwrite,  nodev,	/* 5 winnie */
# else
        nodev,	   nodev,     nodev,	 nodev,     nodev,	/* 5 */
# endif
#endif
	paopen,   paclose,    nodev,     pawrite,   paioctl,	/* 6 printer */
	nulldev,  nulldev,   ioread,     iowrite,   nodev,	/* 7 in-out */
	i3eopen,  i3eclose,  i3eread,    i3ewrite,  i3ectl,	/* 8 ieee */
	0
};

/*
 * Map major device numbers to names.
 */
struct devname {
	int	maj;
	char	*msg;
} devname[] = {
	0,	"Floppy",
	1,	"Winchester",
	4,	"Floppy (unbuffered)",
	5,	"Winchester (unbuffered)",
	-1,	"Unknown device",
};

/*
 * If nswap is 0, then the kernel determins swplo from the
 * root file system size (this means that rootdev & swapdev
 * must be the same), and nswap by reading and testing for
 * errors in 50 block increments.
 */

#ifdef	FLOPPY
int		pipedev		= makedev(0,0);
int		rootdev		= makedev(0,0);
int		swapdev		= makedev(0,0);
int		swplo		= 540;		/* doesn't matter */
int		nswap		= 0;
#else
int		pipedev		= makedev(1,1);
int		rootdev		= makedev(1,0);
int		swapdev		= makedev(1,0);
int		swplo		= 2980;
int		nswap		= 0;
#endif

int		coremap[CMAPSIZ];
int		swapmap[SMAPSIZ];
struct callo	callout[NCALL];
struct mount	mount[NMOUNT];
struct buf	buf[NBUF];
char		buffers[NBUF][BSIZE+BSLOP];
struct buf	rawbuf[NRBUF];
struct text	text[NSEG];
struct cblock	cfree[NCLIST];
struct inode	inode[NINODE];
struct proc	proc[NPROC];
struct file	file[NFILE];
int		sn		= 0;

#ifdef	PARAM
# ifdef	RONLY
int		roflag		= 1;
# else
int		roflag		= 0;
# endif
int		nproc		= NPROC;
int		maxuprc 	= MAXUPRC;
int		timezone	= TIMEZONE;
int		dstflag		= DSTFLAG;
int		hz		= HZ;
struct callo	*lcallout	= &callout[NCALL-1];
struct mount 	*lmount		= &mount[NMOUNT];
struct buf	*lbuf		= &buf[NBUF];
struct buf	*lrawbuf	= &rawbuf[NRBUF];
struct text	*ltext		= &text[NSEG];
struct cblock	*lcfree		= &cfree[NCLIST-1];
struct inode	*linode		= &inode[NINODE];
struct proc	*lproc		= &proc[NPROC];
struct proc	*lprocm		= &proc[NPROC-1];
struct file	*lfile		= &file[NFILE];
#endif
