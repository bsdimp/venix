/* device driver for tecmar ieee 488 interface board */

#include <sys/param.h>
#include <sys/user.h>
#include <sys/tty.h>
#include <sys/proc.h>
#define PRI 15 
#define BASE 0x310
#define IOINT 2		/* interupt priority */
#define MAXN 50		/* maximum number of bytes transferred in single set */

/* states for the driver */

#define CLOSED  0
#define WAITING 1
#define READING 2
#define WRITING 3
#define CONTROL 4

/* 8292 commands */

#define IFC 0xf9	/* gpib interface clear */
#define GTSB 0xf6	/* turn off atn line */
#define TSC  0xfd	/* take synchronized control (turn atn line on) */
#define RST  0xf2	/* reset 8292 */
#define REN 0xf8	/* set remote enable */

/* useful bit flags */

#define TALK 0x40	/* to send talk address */
#define LISTEN 0x20	/* to send listen address */
#define RDYIN 0x1	/* interrupt flag for read */
#define RDYOUT 0x2	/* interrupt flag for write */
#define ERR 0x4		/* interupt flag for error */
#define EOI 0x10	/* interrupt flag for EOI */

/* debuging options */

#define DEBUG on
#ifndef DEBUG
#define DBG(x) ""	/* define as empty for non - debug option */
#else DEBUG		/*define dummy i/o functions */
static int cccc = -1;	/* counter for debug printf */
#define io_outb dout
#define io_inb  din
#define DBG(x) x	/* define as string if debug is on */
#endif


extern int lbolt;
static char i3evec[9];		/* interupt vector */
static int i3estate = CLOSED;	/* current state of interface */
static int i3error = 0;		/* flag to signal i/o errors */
static struct clist i3ewq;	/* queue used between write and interupt routines */
static int i3ewflag = 0;	/* flag to signal end of buf to write */
static int i3eoi = 0;		/* flag to send EOI on last char of write */
static struct {
	int flag;		/* flag for eoi reached */
	struct clist qq;	/* pointer to queue */
	} i3eql[16],*i3erq;	/* io queue for each dev on input */
/* open routine */

i3eopen(dev,flag)
dev_t dev;
int flag;
{
	int i3eint();
	if( minor(dev) >= NODEV) {
		u.u_error = ENXIO;
		return;
		}
	if( i3estate == CLOSED) {
		setiva(0x20 + 4 * IOINT, i3eint,i3evec);
		io_outb(BASE+9,RST);	/* reset 8192 half */
		io_outb(BASE+5,0x2);	/* reset 8291 half */
		i3estate = WAITING;
		io_outb(BASE+12,1<<(IOINT -2));	/* enable hardware interupts */
		io_inb(BASE +1);		/* clear interupt bits */
		}
}

/* read routine */

i3eread(dev)
dev_t dev;
{
	int c,d;
	spl4();
	d = minor(dev);
	c = 0;
	while (u.u_error == 0 && u.u_count != 0 && c != -1) {
		c = getc(&i3eql[d].qq);
		if(c == -1 && !i3eql[d].flag) {
			c = 0;
			i3estart(d); 
			}
		else if( c != -1) c = passc(c);
		}
	if(i3eql[d].qq.c_cc == 0 ) i3eql[d].flag = 0;
	spl0();
}

/* wait for a turn and start input going */

i3estart(dev)
int dev;
{

/* if not already reading this device  wait for a turn on bus */

	if( i3estate != READING || i3erq != &i3eql[dev]) {	/* start input */
		while(i3estate != WAITING) sleep(&i3estate,PRI);
		i3estate = READING;
		if( mktl(dev,-1) ) {
			u.u_error = EIO;
			return;
			}
		i3erq = &i3eql[dev];
		i3erq->flag = 0;
		io_outb(BASE+1,ERR|RDYIN|EOI);	/* set interupt enables  */
		io_outb(0x21,io_inb(0x21) & ~(01 << IOINT));
		io_outb(BASE+5,0);	/* cause interupt */
		}

	else { /* wait for input to happen */
		DBG(if( cccc >= 0) printf( "rd: sleep ");)
		sleep(&i3erq,PRI);
		if( i3error) {
			u.u_error = EIO;
			i3error = 0;
			return;
			}
		DBG(if( cccc >= 0) printf( "rd: done ");)
		}
}

/* write routine */

i3ewrite(dev)
dev_t dev;
{
	int i,c;
	c = 1;
	spl4();
	while( 0 == u.u_error && c != -1) {
		while(i3estate != WAITING) sleep(&i3estate,PRI);
		i3estate = WRITING;
		if( mktl(-1,minor(dev)) ) {
			u.u_error = EIO;
			break;
			}
		for(i=0;i<MAXN; i++) {
			if((c = cpass()) != -1) {
				while(putc(c,&i3ewq)) sleep(&lbolt,PRI);
				}
			else break;
			}
		if( u.u_count == 0) i3ewflag = i3eoi;
		io_outb(BASE+1,ERR|RDYOUT);	/* set interupt enables  */
		io_outb(0x21,io_inb(0x21) & ~(01 << IOINT));
		io_outb(BASE+5,0);	/* cause interupt */
		}
	spl0();
}

/* interupt routine */

i3eint()
{
	int status,c,oldstate;
	status = io_inb(BASE+1);
	if( i3estate == READING) {
		if (RDYIN & status) {
			c = io_inb(BASE);
			while(putc(c,&i3erq->qq)) sleep(&lbolt,PRI);	/* is this possible???? */
			DBG(if(cccc >= 0) printf(" int: wake ");)
			wakeup(&i3erq);
			}
		if(status & EOI) {
			i3erq->flag = 1;
			i3estate = WAITING;
			io_outb(BASE+1,0);	/* disable interupt */
			io_outb(0x21,io_inb(0x21) | (01 << IOINT));
			wakeup (&i3estate);
			}
		}
	else if( (i3estate == WRITING || i3estate == CONTROL) && (RDYOUT & status) ) {
		if( -1 == (c = getc(&i3ewq))) {
			oldstate = i3estate;
			i3estate = WAITING;
			i3ewflag = 0;
			io_outb(BASE+1,0);	/* disable interupt */
			io_outb(0x21,io_inb(0x21) | (01 << IOINT));
			if( oldstate == WRITING) wakeup(&i3estate);
			else wakeup(&i3ewq);
			}
		else {
			if( i3ewflag && i3ewq.c_cc == 0) io_outb(BASE+5,0x6);	/* turn on eoi with char (if needed) */
			io_outb(BASE,c);
			}
		}
	else if( status & ERR) {
		oldstate = i3estate;
		i3estate = WAITING;
		io_outb(BASE+1,0);	/* disable interupt */
		io_outb(0x21,io_inb(0x21) | (01 << IOINT));
		if( oldstate == WRITING) {
			wakeup(&i3estate);
			printf("\nERROR gpib err\n");
			}
		else if ( oldstate == CONTROL ) {
			i3error = 1;
			wakeup(&i3ewq);
			}
		else if ( oldstate == READING) {
			i3error = 1;
			wakeup(&i3erq);
			}
		}
	else printf("\nERROR in i3eint %d (%x)\n",i3estate,status);
	io_outb(0x20,0x20);	/* reset interupt controller */
}

/* set up listener and talker (-1 is controller ) */

mktl(talkadd,listenadd)
int talkadd,listenadd;
{
	static oldtk,oldlis;	/* remember ieee addressees */
	int i,oldstate;

	io_outb(BASE+9,TSC);	/* take sync. control */
	io_outb(BASE+4,0x80);	/* address mode talk only */
	while(putc(0x5f,&i3ewq)) sleep(&lbolt,PRI);	/* untalk */
	while(putc(0x3f,&i3ewq)) sleep(&lbolt,PRI);	/* unlisten */
	if(talkadd != -1) {	/* set up talker */
		while(putc(talkadd | TALK,&i3ewq)) sleep(&lbolt,PRI);	/* set talk address */
		i = 0x40;
		}
	if(listenadd != -1) {	/* set up listener */
		while(putc(listenadd | LISTEN,&i3ewq)) sleep(&lbolt,PRI);	/* set listen address */
		i = 0x80;
		}
	oldstate = i3estate;
	i3estate = CONTROL;
	io_outb(BASE+1,ERR|RDYOUT);	/* set interupt enables  */
	io_outb(0x21,io_inb(0x21) & ~(01 << IOINT));
	io_outb(BASE+5,0);		/* start interupts */
	sleep(&i3ewq,PRI);
	if(i3error) {
		i3error = 0;
		return(1);
		}
	i3estate = oldstate;
	oldtk = talkadd;
	oldlis = listenadd;
	io_outb(BASE+9,GTSB);	/* take ieee out of command mode */
	io_outb(BASE+4,i);		/* set correct address mode on 8291A */
	return(0);
}

/* iocontrol for ieee interface */

i3ectl(dev,com,addr)
{
	int i;
	spl4();
	switch(com) {
				/* fix state of io driver */
	case 0: 
		i3erq = i3eql;
		for(i=0;i<16;i++) {
			i3erq->flag = 0;
			while( -1 != getc(&i3erq->qq) );
			i3erq++;
			}
		while( -1 != getc(&i3ewq) );
		io_outb(BASE+1,0);	/* disable interupt */
		io_outb(0x21,io_inb(0x21) | (01 << IOINT));
		i3estate = CLOSED;
		break;
				/* do REMOTE ENABLE */
	case 1: io_outb(BASE+9,REN);
		break;
	case 2: i3eoi = 1;	/* turn EOI on */
		break;
	case 3: i3eoi = 0;	/* turn EOI off */
		break;
	case 4: io_outb(BASE+9,IFC);	/* do interface clear */
		break;
#ifdef DEBUG
	case 99:	/* turn debug on or off */
		cccc = ( cccc >= 0)? -1:0;
#endif
	default: break;
	}
	spl0();
}

/* dummy i/o routines that print their arguments on console (used for debugging) */
#ifdef DEBUG
#undef io_outb 
#undef io_inb

	/* debuging out command */

	dout(port,data)
	int port;
	unsigned char data;
	{
		if(cccc >= 0 ) {
			printf("o:%x %x ",port,data);
			if(0 == (++cccc) % 8) printf("\n");
			}
		io_outb(port,data);
	}

	/* debuging data in */

	din(port)
	int port;
	{
		unsigned char data;
		data =io_inb(port);
		if( cccc >= 0) {
			printf("i:%x %x ",port,data);
			if(0 == (++cccc) % 8) printf("\n");
			}
		return(data);
	}
#endif
