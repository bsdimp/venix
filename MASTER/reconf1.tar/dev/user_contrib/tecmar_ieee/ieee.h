/* constants for ieee ioctl() */

#define IOCREN 1
#define IOCEON 2
#define IOCEOFF 3
#define IOCIFC 4
