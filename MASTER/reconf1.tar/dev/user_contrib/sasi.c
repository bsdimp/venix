#define	NOPARTITION		/* don't read partition table */

/*	XT winchester driver (for the IBM XT).
*	Modified to work through a SASI Bus (for Eagle 1600).
*		Version 86/2.0		May 9, 1983
*			Edited:	5/17/84
*
*****************************************************************
*								*
*	(C)Copyright by VenturCom, Inc. 1983, 1984		*
*								*
*	All rights reserved:	  VENTURCOM INC. 1983,1984	*
*								*
*	This source listing is supplied in accordance with	*
*	the Software Agreement you have with VenturCom and	*
*	the Western Electric Company.				*
*								*
****************************************************************/
#include <sys/param.h>
#include <sys/buf.h>
#include <sys/user.h>
#include <sys/devparm.h>
#include <sys/xtblk0.h>

#define	NDRV	2			/* number of drives */
#define	IOADD	((struct xt *) 0x340)	/* i/o register origin */
#define	NHEAD	4			/* number of heads */
#define	SECHEAD	17			/* sectors per head */
#define	IOINT	2			/* interrupt request number */
#define	MAXFER	(512*32)		/* maximum DMA xfer size in bytes */

#define	DMACHAN		1	/* DMA channel number */
#define	DMAPAGE		0x83	/* channel dependent: 1 = 0x83, 3 = 0x82 */
#define	DMAREAD		(0x44+DMACHAN)
#define	DMAWRITE	(0x48+DMACHAN)
#define	DMAADDR		(2*DMACHAN)
#define	DMACOUNT	(DMAADDR+1)
#define SASI_DATA	(0x340)
#define SASI_STAT	(0x342)
#define SASI_CTRL	(0x344)
/*
#define SASI_DATA	(&IOADD->x_data)
#define SASI_STAT	(&IOADD->x_stat)
#define SASI_CTRL	(&IOADD->x_mask)
*/

/*
 * XT winchester controller commands and formats.
 */
#define	READ		0x08	/* read data */
#define	WRITE		0x0a	/* write data */
#define	SENSE_STAT	0x3
#define	DMA_CLRF	0x0c	/* portid.lib */
#define	DMA_MODE	0x0b	/* portid.lib */
#define	DMA_MASK	0x0a	/* portid.lib */
#define	CD		0x01	/* tmpio.asm page 2	*/
#define	REQ		0x10	/* tmpio.asm page 2	*/
#define MSG		0x04	/* tmpio.asm page 2	*/
#define	BSY		0x08	/* tmpio.asm page 2	*/
#define	CORRECTED	0x98	/* same			*/
#define	ERR_BIT		0x02	/* same			*/

#define	TRUE		1
#define	FALSE		0


struct xt {			/* i/o register layout */
	unsigned char x_data;
	unsigned char x_stat;
	unsigned char x_selt;
	unsigned char x_mask;
};

unsigned int	xt_nhead = NHEAD;	/* for benefit of external changes */
unsigned int	xt_sechd = SECHEAD;
unsigned int	xt_mxfer = MAXFER;

struct xt_cmd {			/* command packet */
	unsigned char c_cmmd;
	unsigned char c_head;
	unsigned char c_sect;
	unsigned char c_cyln;
	unsigned char c_bcnt;
	unsigned char c_ctrl;
} xt_cmd;

struct xtmsg {			/* convert error numbers to messages */
	char	num;
	char	*msg;
} xtmsg[] = {
	0xFF,	"Controller timeout",
	0x21,	"Illegal disk address",
	0x20,	"Invalid command",
	0x19,	"Bad track",
	0x18,	"Correctable data error",
	0x15,	"Seek error",
	0x14,	"Sector not found",
	0x12,	"No address mark",
	0x11,	"Data error",
	0x10,	"ID error",
	0x06,	"No track 0",
	0x04,	"Drive not ready",
	0x03,	"Write fault",
	0x02,	"No seek complete",
	0x01,	"No index signal",
	0x00,	"Unknown error",
};

struct {			/* disk partitions */
	unsigned nblock;	/* number of 512 byte blocks */
	unsigned oblock;	/* offset in blocks for first block */
} xt_sizes[8*NDRV] = {
				/***	Drive 0		      ***/
	3739+34,1+34,		/*  1.8  2980 system, 750 swap	*/
	340+34,	3740+34,	/*   .2  tmp & pipes		*/
	16660+34,4080+34,	/*  8.0  user			*/
	0,	0,		/*  0.0  dos			*/
	303*17*4,0,		/* full disk including hidden
					34 blocks		*/
	0,	0,
	0,	0,
	-1,	0,		/* physical			*/

				/***	Drive 1		      ***/
	303*17*4,	0,	/* 10.00  user			*/
	0,	0,
	0,	0,
	0,	0,
	0,	0,
	0,	0,
	0,	0,
	-1,	0,		/* physical			*/
};

#define	b_cylin	b_resid		/* redefine for readability */

struct	devtab	xttab;
struct	buf *xt_bp;	/* temp buf pointer for raw i/o stradling of 65kb */
int	xtfirst;	/* flag:	0 = first time, 1 = already started */
char	xtcntrl;	/* control:	0 = normal, 1 = more, -1 = straddle */
char	xtvec[9];	/* interrupt transfer vector */

unsigned char	cur_stat[6] = {0,0,0,0,0,0};
unsigned char	opt = 0x0;	/* tmpio.asm page 10 (WINCH1) */

xtstrategy(abp) struct buf *abp; {
	register struct buf *bp;
	register int unit;
	int xtintr();

	
	if( xtfirst == 0 ){
		/*
		 * Initialize the winchester controller.
		 */
		setiva( 0x28, xtintr, xtvec);	/* set up iva */

		/*
		 * Read in partition table from physical block 34 
		 * if this is the first 0-3 partition table access.
		 */
#ifndef NOPARTITION
		 if ( (abp->b_dev&037) != 7){
		    int part;
    
		    xtfirst++;
		    bp = (struct buf *)bread( abp->b_dev | 7, 0);
		    if( ((struct xp *)bp->b_addr)->xp_sig == XP_SIG)
		    for( unit=0; unit<4; unit++ ){
		        switch(((struct xp *)bp->b_addr)->xp_tab[unit].xp_sys){
		        case XP_SYS:	part = 0;	break;
		        case XP_TMP:	part = 1;	break;
		        case XP_USR:	part = 2;	break;
		        default:	part = 3;	break;
		        }
		    xt_sizes[part].nblock =
		        ((struct xp *)bp->b_addr)->xp_tab[unit].xp_size;
		    xt_sizes[part].oblock =
		        ((struct xp *)bp->b_addr)->xp_tab[unit].xp_start;
		    }
		    brelse(bp);
		    /*
		     * Get a buffer for i/o which stradles a 64kb boundry.
		     */
		    xt_bp = (struct buf *)getblk(NODEV);
		}
#else
		xtfirst++;
		xt_bp = (struct buf *)getblk(NODEV);
#endif
	}
	unit = (bp = abp)->b_dev&037;
	if(unit>=8*NDRV ||
	    (bp->b_blkno+((255-bp->b_wcount)>>8)) > xt_sizes[unit].nblock){
		bp->b_flags |= B_ERROR;
		iodone(bp);
		return;
	}
	bp->b_cylin = (bp->b_blkno + xt_sizes[unit].oblock) /(NHEAD*SECHEAD);
	spl5();
	disksort(&xttab, bp);
	if( xttab.d_active==0 )
		xtstart();
	spl0();
}

xtstart() {
	register struct buf *bp;
	register unsigned int count;
	unsigned int addr;
	struct ib { char lobyte, hibyte; };

	if( (bp = xttab.d_actf) == NULL )
		return;
	xttab.d_active++;
	xtcntrl = 0;
	/*
	 * Set up DMA controller.
	 */	
	io_outb( DMA_CLRF, opt);	/*	SASI_TRANS	*/
	
	if( bp->b_flags&B_READ )
		io_outb( DMA_MODE, DMAREAD);
	else
		io_outb( DMA_MODE, DMAWRITE);
	addr = (unsigned int)bp->b_addr;
	if( bp->b_flags&B_PHYS ){
		/*
		 * Check for stradling of 64kb boundry.
		 */
		if( addr > 0xFE00 ){
			xtcntrl--;
			if( (bp->b_flags&B_READ)==0 ){
				addr = spl6();
				count = u.u_ds;
				u.u_ds = (bp->b_xmem<<12) + 32;
				copyin(bp->b_addr - 512, xt_bp->b_addr, 512);
				u.u_ds = count;
				splx(addr);
			}
			addr = (unsigned int)xt_bp->b_addr;
			goto cont;
		}
		io_outb( DMAPAGE, bp->b_xmem);
		io_outb( DMAADDR, ((struct ib *)&bp->b_addr)->lobyte);
		io_outb( DMAADDR, ((struct ib *)&bp->b_addr)->hibyte);
		count = ((-bp->b_wcount << 1) + 0x1FF) & ~0x1FF;

		/*
		 * Long DMA transfers will delay the RAM refresh of memory
		 * on the I/O bus so that memory can get corrupted.
		 *
		 * Also check for 64kb DMA wraparound.
		 */
		if( count > xt_mxfer ||
		    ((unsigned int)bp->b_addr) + count < count ){
			xtcntrl++;
			if( count > xt_mxfer &&
			    ((unsigned int)bp->b_addr) + count >= count )
				count = xt_mxfer;
			else {
				count = -((unsigned int)bp->b_addr);
				if( (count&0x1FF) != 0 )    /*bad boundary */
					count &= ~0x1FF;
				else
					bp->b_xmem++;
			}
			bp->b_addr += count;
			bp->b_wcount += count>>1;
		}
	} else {
cont:		count = addr >> 4;
		count += getds();
		io_outb( DMAPAGE, count >> 12);
		io_outb( DMAADDR, (count<<4) + (addr&017));
		io_outb( DMAADDR, count>>4);
		count = 512;
	}
	xt_cmd.c_bcnt = count >> 9;
	count--;
	io_outb( DMACOUNT, count);
	io_outb( DMACOUNT, count>>8);
	io_outb( DMA_MASK, 1);		/*	SETDMA1		*/

	/*
	 * Set up the rest of XT command packet.
	 */
	count = bp->b_blkno + xt_sizes[ addr = bp->b_dev&037 ].oblock;
	xt_cmd.c_head = count>>16;
	xt_cmd.c_head |= (addr&030)>>3; /* original */
	xt_cmd.c_head &= 0xff;	
	xt_cmd.c_sect = count >>8;
	xt_cmd.c_sect &= 0xff;
	xt_cmd.c_cyln = count & 0xff;
	xt_cmd.c_ctrl = opt;

	/*
	 * Start the action.
	 */
	if ( !xtcmd( bp->b_flags&B_READ ? READ : WRITE) ){
		xtcntrl = 2;
		xtintr();			/* print the error */
		return;
	}
	io_outb(SASI_CTRL, 0xc7);		
	io_outb(0x21, io_inb(0x21) & ~(01 <<IOINT) );
}

xtintr() {
	register struct buf *bp;
	register int i;
	char j = 0xFF;

	bp = xttab.d_actf;
	if( xtcntrl == 2 )
		goto error;
	io_outb( 0x21, io_inb(0x21) | (01<<IOINT) );
	io_outb( 0x20, 0x20);
	io_outb(SASI_CTRL, 0xff);
	if( xttab.d_active!=0 ){
		if ( (input_stat() & ERR_BIT) == ERR_BIT){
			xtcmd(SENSE_STAT);
			j = input_stat();
			if (j == CORRECTED ){
				bp->b_flags  |= B_ERROR;
error:
				for( i = 0; xtmsg[i].num!=0; i++ )
					if( xtmsg[i].num == j )
						break;
				deverror(bp, xtmsg[i].msg, j);
			}
			goto done;
		}
		/*
		 * Finished with this transfer ?
		 */
		if( xtcntrl ){
			if( xtcntrl < 0 ){
				if( bp->b_flags&B_READ ){
					i = u.u_ds;
					u.u_ds = (bp->b_xmem<<12) + 32;
					copyout(xt_bp->b_addr,
					    bp->b_addr - 512, 512);
					u.u_ds = i;
				}
				bp->b_addr += 512;
				bp->b_xmem++;
 				bp->b_wcount += 256;
			}
			if( bp->b_wcount >= 0 )
				goto done;
			bp->b_blkno += xt_cmd.c_bcnt;
		} else {
done:			xttab.d_active = 0;
			xttab.d_actf = bp->av_forw;
			bp->b_resid = 0;
			iodone(bp);
		}
	}
	xtstart();
}

int
input_stat()
{
	unsigned int	temp;
	int	bx = 0;

	cur_stat[bx] = -1;
loop:	for(;;){
		if (((temp = io_inb(SASI_STAT)) & BSY) != BSY) goto endit;
		if ((temp & REQ) == REQ) break;		/* signal steady? */
	}
	cur_stat[bx++] = io_inb(SASI_DATA);
	if ((temp & MSG) != MSG) goto loop;
endit:	
	return(cur_stat[0]);
}
	
select(){
	register int	i;

	if (!steady_state()){
		return(FALSE);
	}
	io_outb(SASI_DATA, 1);	/* select controller bit 1	*/
 	io_outb(SASI_CTRL, 0xfe); /* not select?*/
	for(i=0; i<100; i++)
		if ((io_inb(SASI_STAT)&0x1f) == (REQ + BSY + CD)) goto worked;
worked:	io_outb(SASI_CTRL, 0xff);
	return(steady_state());
}

steady_state(){
	register int	i;
	unsigned int	temp;

	temp=io_inb(SASI_STAT);
	for(i=0; i<100; i++)
		if (temp != io_inb(SASI_STAT)) return(FALSE);
	return(TRUE);
}

xtcmd(command){
	register char *x;
	register int i;

	xt_cmd.c_cmmd = command;
	select();

	x = (char *) &xt_cmd;
	i = sizeof(xt_cmd);
	while( i-- ){
		while ((io_inb(SASI_STAT) & REQ) != REQ);
		io_outb(SASI_DATA, *x++);
	}
	return(TRUE);
}

xtread(dev) { aphysio(xtstrategy, dev, B_READ); }

xtwrite(dev) { aphysio(xtstrategy, dev, B_WRITE); }


xtioctl(dev, cmd, addr) char *addr; {
	register int i;
	struct diskparm buf;

	if( cmd == I_GETDPP ){
		if( xtfirst==0 )	/* make sure data is accurate */
			brelse( bread(dev,0) );
		i = dev&037;
		buf.d_nblock = xt_sizes[i].nblock;
		buf.d_offset = xt_sizes[i].oblock;
		buf.d_nsect = xt_sechd;
		buf.d_nhead = xt_nhead;
		buf.d_ntrack = 0;		/* don't care */
		if( copyout( &buf, addr, sizeof(buf)) )
			u.u_error = EFAULT;
	} else
		u.u_error = EINVAL;
}
