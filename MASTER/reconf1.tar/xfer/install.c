/*
 *		VENIX/XT Installation Program	Nov 17, 1983
 *		   Version 2.0    6/14/84
 *
 *	Defines:
 *		XT	for ibm/xt
 *		DAVONG	for davong 5 mb system
 *
 *	Compile as:	cc -s -O -o init install.c
 *	and put on the "Bootable Xfer" floppy in "/f0/etc/init".
 */
#ifndef	DAVONG
#define	XT
#endif

#include <signal.h>
#undef NSIG			/* to prevent redefine errors in <param.h> */
#include <sgtty.h>
#include <a.out.h>
#include <ctype.h>
#include <sys/param.h>
#include <sys/filsys.h>
#ifdef	XT
#include <sys/devparm.h>
#include "../dev/xtblk0.h"
#endif

#define DEL 	   ('H'&037)	/* delete key */
#define NUSR_BOOT	508L	/* loc. of #users variable in floppy boot */
#define	SN_BOOT		510L	/* loc. of serial no. in floppy boot */
#define NUSR_INIT	4L	/* offset to #users variable in /etc/init */
#define	SN_INIT		(508L+512L)

#define pf printf

#ifdef	XT
int	usize = 16660;		/* default user area size */
#else
int	usize = 6334;		/* 5mb Davong */
#endif
int	tsize = 340;		/* default tmp area size */
int	ssize = 2980;		/* default sys area size */
int	swapsiz = 750;		/* default swap size */

struct	nlist symbols[] = {	/* symbols looked for to patch in /venix */
	"_timezon",0,0,
	"_dstflag",0,0,
	"_proc",0,0,
	"_rootdev",0,0,
	"_swapdev",0,0,
	"_pipedev",0,0,
	"",0,0
} ;

struct nlist *pnl;

struct tz {			/* timezone info */
        char	*msg;
        int	min;
} tz[] = {
        "EST", 5*60,	"PST",	8*60,	"MST",	7*60,
        "CST", 6*60,	"AST",	4*60,	"JST",	-9*60,
        "GMT",	0, 0, 0
};

struct exec header;

char clear[] = "\033H\033J\033\016";	/* clear and reset screen */
char hlon[] = "\033\006";		/* highlight */
char hloff[] = "\033\005";
char rvon[] = "\033\010";		/* reverse video */
char rvoff[] = "\033\007";

#ifdef	XT
struct xp xp;
#endif
char	buf[512];
struct sgttyb sgbuf;

int sn;
int nusr;

main(){
	char *cp, c;
	int i, k, fd1;
	int a, b, n;
	long lseek();

	if( open("/dev/console",2) < 0 )	/* open standard error */
		for( ;; )
			;
	dup(0);			/* std in */
	dup(0);			/* std out */

	for (i = 0; i < 16; ++i)
		signal(i,SIG_IGN);	/* ignore all signals */

	ioctl(1,TIOCGETP,&sgbuf);	/* turn off echo */
	sgbuf.sg_flags = CRMOD|CRT;
	ioctl(1,TIOCSETP,&sgbuf);

        /*
         * find out number of users and system serial number,
         * stored in floppy boot block
         */

        if ((fd1 = open("/dev/f0",0)) < 0)
                fatal("Can't open /dev/f0\n");
        lseek(fd1, NUSR_BOOT, 0);
        read(fd1, &nusr, sizeof(nusr));
        lseek(fd1, SN_BOOT, 0);
        read(fd1, &sn, sizeof(sn));
        close(fd1);

#ifdef	XT
	pf("%sXFER/XT%s     Version 2.0\n\n",hlon,hloff);
#else
	pf("%sXFER/DAVONG 5mb	Version 2.0\n\n",hlon,hloff);
#endif
	pf("Do you wish to prepare the winchester hard disk\n");
	pf("for VENIX/86 operation?");
	if (answer() == 0){
		pf("The shell will be executed.\n\n");
		signal(SIGHUP,SIG_DFL);
		signal(SIGINT,SIG_DFL);
		signal(SIGQUIT,SIG_DFL);
		sgbuf.sg_flags = ECHO|CRT|CRMOD;
		ioctl(1,TIOCSETP,&sgbuf);
                execl("/bin/sh","sh","-i",0);
                fatal("Cannot execute the shell `/bin/sh'.\n");
	}
	sleep(2);

	/*
	 * PART I
	 */

	pf("%s%s\t\tVENIX/86 Installation Procedure%s\n\n",clear,hlon,hloff);
	pf("%sPart I%s    (Disk Partitions)\n\n",hlon,hloff);
#ifdef	XT
	if( (i = open("/uboot/xtblk0",0)) < 0 )
		fatal("Cannot find partition file (/uboot/xtblk0).\n");
	if( (fd1 = open("/dev/w0.phy",2)) < 0 )
		fatal("Error in accessing winchester.\n");
	read(i,&xp,512);
	close(i);
	pf("Are the default winchester partitions acceptable?");
	if( answer()==0 ){
		pf("\nSizes are in cylinders (68 blocks per cylinder).\n");
		pf("\nDesired size of system area (normal 55) [55 to 100] ? ");
		i = getnum(55,100);
		if( i > 55 ){
			a = (68*i - 2980 - 10)/50;
			a *= 50;
pf("\nChoose the number of blocks for swapping [750 to %d] (intervals of 50) ? ",a);
			swapsiz = getnum(750,a);
		}
		ssize = 68*i - 10 - swapsiz;
		xp.xp_tab[0].xp_e_c = i - 1;
		xp.xp_tab[0].xp_size = i*68 - 1;

		k = i;
		pf("\nDesired size of temporary area (normal 5) [5 to 15] ? ");
		i = getnum(5,15);
		tsize = i*68;
		xp.xp_tab[1].xp_s_c = k;
		xp.xp_tab[1].xp_e_c = k + i - 1;
		xp.xp_tab[1].xp_start = k*68;
		xp.xp_tab[1].xp_size = tsize;

		k += i;
		pf("\nDesired size of DOS partition [0 to 100] ? ");
		i = getnum(0,100);
		if( i > 0 ){
		 xp.xp_tab[3].xp_s_c = 305 - i;
		 xp.xp_tab[3].xp_s_s = 17 | ( ((305 - i)>>2) & 0300 );
		 xp.xp_tab[3].xp_e_c = 304;
		 xp.xp_tab[3].xp_e_s = 17 | ( (304>>2) & 0300);
		 xp.xp_tab[3].xp_start = (305 - i)*68;
		 xp.xp_tab[3].xp_size = i*68;
 pf("Use DOS's FDISK and FORMAT commands to create the DOS area.\n");
		 sleep(3);
		}
		i = 305 - k - i;
		xp.xp_tab[2].xp_start = k*68;
		xp.xp_tab[2].xp_size = usize = i*68;
		i += k - 1;
		xp.xp_tab[2].xp_s_c = k;
		xp.xp_tab[2].xp_e_c = i;
		xp.xp_tab[2].xp_e_s = 17 | ( (i>>2) & 0300 );
	}
	write(fd1,&xp,512);
	close(fd1);
#else
	pf("Partitions are fixed at (in blocks):\n");
	pf("	System = %d\n",ssize);
	pf("	Swap = %d\n",swapsiz);
	pf("	Temp = %d\n",tsize);
	pf("	User = %d\n",usize);
#endif
	sleep(3);

	/*
	 * PART II
	 */

	pf("%s%s\t\tVENIX/86 Installation Procedure%s\n\n",
		clear,hlon,hloff);
	pf("%sPart II%s    (User Area)\n\n",hlon,hloff);
	pf("Do you wish to create the user area?");
	if (answer() == 0)
		goto part3;

	if( checkfs("/dev/w0.usr",usize)){
		pf("\n%sWARNING%s: There is a VENIX file system already\n",
			hlon,hloff);
		pf("on the user area. Do you wish to continue?", hloff);
		if (answer() == 0)
			goto part3;
	}

	sprintf(buf,"%d",usize);
	pf("\nDo you wish to check for bad blocks on the user area?");
	if (answer() == 1){
		pf("\nGet a cup of coffee; this will take about 10 minutes.\n");
		if (run("/bin/mkfs","mkfs","-b","/dev/w0.usr",buf,0))
			fatal("Error in accessing winchester (mkfs)\n");
	} else {
		pf("\nCreating a file system on the user area.\n");
		if (run("/bin/mkfs","mkfs","/dev/w0.usr",buf,0))
			fatal("Error in accessing winchester (mkfs)\n");
	}
	if (mount("/dev/w0.usr","/usr",0) < 0)
		fatal("Can't mount user area\n");

	chdir("/usr");
	pf("\nTar the user area to the winchester from the floppy.\n");
	run("/bin/tar","tar","xf7","/dev/rf0",0);
	chdir("/");

	umount("/dev/w0.usr");
	pf("\nUser area completed.");

part3:
	sleep(3);

	/*
	 * PART III
	 */

	pf("%s%s\t\tVENIX/86 Installation Procedure%s\n\n",
		clear,hlon,hloff);
	pf("%sPart III%s    (System Area)\n\n",hlon,hloff);
	pf("Do you wish to create the system area?");
	if (answer() == 0)
		goto part4;

	pf("\nCheck the swapping area for bad blocks.\n");
	if( (fd1 = open("/dev/w0.sys",2)) < 0 )
		fatal("Error in accessing winchester\n");
	lseek(fd1, ssize*512L, 0);
	for( i = 0; i < swapsiz; i++ )
		if( read( fd1, buf, 512) != 512 ){
			pf("%sWARNING%s: bad block(s)\n",hlon,hloff);
			break;
		}
	pf("%d blocks for swapping\n",i);

	sprintf(buf,"%d",tsize);
	pf("\nCheck the temporary area for bad blocks.\n");
	run("/bin/mkfs","mkfs","-b","/dev/w0.tmp",buf,0);

#ifdef	XT
	/*
	 * Decide if 4 head or 2 head drive.
	 */
	{
		struct diskparm buf;

		if( (i = open("/dev/rw0.sys",0)) < 0 )
			fatal("Cannot open /dev/rw0.sys.\n");
		buf.d_nhead = 0;
		ioctl(i, I_GETDPP, &buf);
		close(i);
		if( buf.d_nhead == 2 ){
		    if( (i = open("/uboot/xtboot.2hd",0)) < 0 )
			fatal("Cannot find boot file (/uboot/xtboot.2hd).\n");
		} else {
		    if( (i = open("/uboot/xtboot",0)) < 0 )
			fatal("Cannot find boot file (/uboot/xtboot).\n");
		}
	}
	read(i,buf,512);
	close(i);
	lseek(fd1,0L,0);
	write(fd1,buf,512);
#endif	XT
	close(fd1);

	if( checkfs("/dev/w0.sys",ssize)){
	       pf("\n%sWARNING:  There is a VENIX file system already\n",hlon);
		pf("on the system area.%s  Do you wish to continue?",hloff);
		if (answer() == 0)
			goto part4;
	}

	sprintf(buf,"%d",ssize);

	pf("\nPlease wait several minutes.\n");
	if (run("/bin/mkfs","mkfs","-b","/dev/w0.sys", buf, 0))
		fatal("Error in accessing winchester (mkfs)\n");

	if( mount("/dev/w0.sys", "/usr", 0) < 0 )
		fatal("Can't mount system area\n");
	chdir("/usr");
	pf("\nTar the system area to the winchester from the floppy.\n");
	run("/bin/tar","tar", "xf4-", "/dev/rf0", ".", 0);
	chdir("/");
	umount("/dev/w0.sys");

part4:
	/*
	 * Insert serial number
	 */
	if( (i = open("/dev/w0.sys",2)) < 0 )
		fatal("Cannot open /dev/w0.sys\n");
	lseek(i, SN_INIT,0);
	write(i,&sn,sizeof(sn));
	close(i);
	
	if( mount("/dev/w0.sys","/usr",0) < 0 )
		fatal("Cannot mount /dev/w0.sys\n");

	/*
	 * Patch /etc/rc with tmp file system size.
	 */
	if( (fd1 = open("/usr/etc/rc",2)) < 0 )
		fatal("Cannot modify file /etc/rc\n");
	if( (i = read(fd1,buf,512)) > 0 ){
		lseek(fd1,0L,0);
		for( cp = buf; cp < &buf[i]; cp++ )
		if( strncmp(cp,"/etc/mkfs /dev/w0.tmp ",22) == 0 ){
			cp += 22;
			if( (k = cp - buf) > i )
				break;
			write(fd1,buf,k);
			sprintf(buf,"%5d",tsize);
			write(fd1,buf,5);
			while( *cp++ != '\n' && cp < &buf[i] )
				;
			cp--;
			write(fd1,cp,&buf[i]-cp);
			break;
		}
	}
	close(fd1);

	/*
         * patch /etc/init with # of users
         */
	if( nusr < 1 || nusr > 16 ){
		nusr = 0;
	} else if( nusr > 1 ){
		if ((fd1 = open("/usr/etc/init",2)) < 0)
                	fatal("Error 1 in system area\n"); 

		/* NUSR_INIT tells us positition of
		 * symbol determining # of users,
		 * offset from end of code area 
		 */

		read(fd1, &header, sizeof(struct exec));
		lseek(fd1, header.a_text + NUSR_INIT + sizeof(struct exec), 0);
 		read(fd1, &i, sizeof(i));
                if (i < 1 || i > 16){	/* check we're in right spot */
			nusr = 0;
                } else {
			lseek(fd1,header.a_text+NUSR_INIT+sizeof(header),0);
                        write(fd1, &nusr, sizeof(nusr));
                }
                close(fd1);
	}

	/*
	 * Copy the venix kernel from floppy to winchester.
	 */
	if( (k = open("/venix",0)) < 0 )
		fatal("Cannot open /venix\n");
	close( creat("/usr/venix",0444) );
	if( (fd1 = open("/usr/venix",2)) < 0 )
		fatal("Cannot create `venix' on the winchester\n");
	while( (i = read(k,buf,512)) > 0 )
		write(fd1,buf,i);
	lseek(fd1,0L,0);
	if( read(fd1, &header, sizeof(struct exec)) != sizeof(struct exec) ||
	   N_BADMAG(header) )
		fatal("venix header is bad\n");

	/*
	 * Read symbol table from /venix so we can
	 * patch device numbers and timezone info
	 */
	nlist("/usr/venix",symbols);
	for (pnl = symbols; *(pnl->n_name); ++pnl)
		if (pnl->n_type == 0)
			fatal("Bad venix namelist\n");
	for( i = 0; i<6; )
	symbols[i++].n_value += (long)sizeof(struct exec)
		+ (header.a_magic!=0407 ? header.a_text : 0);

	/*
	 * change device numbers
	 */
	i = 0x0100;
	lseek(fd1, (long)symbols[3].n_value, 0);
	write(fd1, &i, sizeof(i));
	lseek(fd1, (long)symbols[4].n_value, 0);
	write(fd1, &i, sizeof(i));
	lseek(fd1, (long)symbols[5].n_value, 0);
	i = 0x0101;
	write(fd1, &i, sizeof(i));

	/*
	 * PART IV
	 */

	pf("%s%s\t\tVENIX/86 Installation Procedure%s\n\n",
		clear,hlon,hloff);
	pf("%sPart IV%s    (Time Zone Selection)\n\n", hlon,hloff);

loop3:
	pf("	1 - Eastern time zone (EST)\n");
	pf("	2 - Pacific time zone (PST)\n");
	pf("	3 - Mountain time zone (MST)\n");
	pf("	4 - Central time zone (CST)\n");
	pf("	5 - Atlantic time zone (AST)\n");
	pf("	6 - Japan time zone (JST)\n");
	pf("	7 - Greenwich mean time zone (GMT)\n");
	pf("	8 - Other\n\n");
	pf("Enter a number and press `return' to select your time zone [1 to 8] ? ");
	n = getnum(1,8);
	if( n-- < 8 ){
		pf("You have selected the %s zone. Are you sure?",
			tz[n].msg);
		if( answer()==0 )
			goto loop3;
		n = tz[n].min;
	} else {
		pf("Enter the minutes west of GMT (minus for east) [-720 to 720] ? ");
		n = getnum(-720,720);
	}
	pf("Does daylight saving time ever apply here?");

	a = answer();

	lseek(fd1, (long)symbols[0].n_value, 0);
	write(fd1, &n, sizeof(n));
	lseek(fd1, (long)symbols[1].n_value, 0);
	write(fd1, &a, sizeof(a));
	close(fd1);

	sync();

	if ( nusr==0 ) {
		pf("\n%sWARNING:%s configuration error will cause this system",
			hlon,hloff);
             	pf("\tto be single-user only.");
	} else
		pf("\nSystem will be %d user.", nusr);
	pf("\n\n%sInstallation complete.%s\n",hlon,hloff);
#ifdef	XT
	pf("Remove XFER floppy and reboot.\n");
#else
	pf("Remove XFER floppy and insert the BOOT floppy.\n");
	pf("Type <Ctrl><Alt><delete> to boot.  The `venix'\n");
	pf("image will be read off the floppy but execute\n");
	pf("from the winchester.   NOTE! The timezone, dst\n");
	pf("have been updated only on the `venix' image on\n");
	pf("the winchester, thus mount the boot floppy and\n");
	pf("copy the venix image from winchester to floppy\n");
	pf("and reboot.  Now the timezone and etc. will be\n");
	pf("correct.\n");
#endif
	while (1) ;
}

answer()
{
	char c;

	pf(" (%sy%s or %sn%s) ",hlon,hloff,hlon,hloff);

	while(1){
		switch(xgetchar()){
		case 'y':
		case 'Y':
			pf("%sYes%s\n",rvon,rvoff);
			return(1);
		case 'n':
		case 'N':
			pf("%sNo%s\n",rvon,rvoff);
			return(0);
		default:
			pf("\007");
		}
	}
}
	
getnum(min,max)
int min,max;
{
	register char *cp;
	char c, cbuf[10];
	int r, flags;

	ioctl(0,TIOCGETP,&sgbuf);
	flags = sgbuf.sg_flags;
	sgbuf.sg_flags = RAW;
	ioctl(0,TIOCSETP,&sgbuf);

	while (1){
		pf("%s",rvon);
                for (cp = cbuf; cp < cbuf + 10;){
                        read(0,&c,1);		
                        if (  isdigit(c) || 
			   ( (cp == cbuf) &&		/* first digit? */
		             ((c == '+' && max >= 0) || /* '+' okay? */
			      (c == '-' && min < 0)) )  /* '-' okay? */
					) { 
                                *cp++ = c;
                                pf("%c",c);
                        }
                        else if ((c == '\r' || c == '\n') && cp > cbuf){
				pf("\r\n");
                                break;
			}
                        else if (c == DEL){
                                if (cp > cbuf){
                                        pf("%s\b \b%s",rvoff,rvon);
                                        --cp;
                                } else pf("\007");
                        } else 
                                pf("\007");		/* beep */
                }
                *cp = 0;
                r = atoi(cbuf);
		pf("%s",rvoff);

		/* check number bewteen bounds, 
		 * allowing also for unsigned values
		 */
                if (min <= r && r <= max){
                	sgbuf.sg_flags = flags;
			ioctl(0,TIOCSETP,&sgbuf);
	                return(r);
		}

		pf("\r\n%sInvalid number%s: please type again\r\n? ",
			hlon,hloff);
	}
}

run( name, v )
char *name; char *v;
{
	register char **rv;
	register int i;
	int stat;

	pf("\t");
	for( rv = &v; *rv != (char *)0; rv++ )
		pf("%s%s%s ", hlon,*rv,hloff);
	pf("\n");
	if( (i = fork()) == 0 ){
		execv( name, &v);
		fatal("BOOTABLE XFER floppy corrupted (can not find %s)\n",
			name);
	}
	while( (i != wait(&stat)) )
		;
	return(stat);
}

checkfs( name, fsize )
char *name;
unsigned int fsize;
{
	int fd;
	static struct filsys fs;

	if( (fd = open( name, 0)) < 0 ){
		pf("XFER: cannot open %s.\n",name);
		return(1);
	}
	lseek( fd, 512L, 0);
	if( read( fd, &fs, sizeof(fs)) != sizeof(fs) ){
		pf("XFER: Cannot read %s.\n",name);
		close(fd);
		return(1);
	}
	close(fd);
	if( fs.s_isize<fsize/3 && fs.s_fsize==fsize && fs.s_nfree<=100
		&& fs.s_ninode <=100 )
			return(1);
	return(0);
}

fatal(f,s1,s2)
char *f, s1, s2;
{
	pf("\n%sFATAL ERROR: %s",hlon,hloff);
	pf(f,s1,s2);
	pf("\nXFER halting.  Consult your manual for assistance\n");
	sync();
	while (1) ;
}

xgetchar(){
	int flags;
	char c;

	ioctl(0,TIOCGETP,&sgbuf);
	flags = sgbuf.sg_flags;
	sgbuf.sg_flags = RAW;
	ioctl(0,TIOCSETP,&sgbuf);
	read(0, &c, 1);
	sgbuf.sg_flags = flags;
	ioctl(0,TIOCSETP,&sgbuf);
	return(c == '\r' ? '\n' : c);
}
