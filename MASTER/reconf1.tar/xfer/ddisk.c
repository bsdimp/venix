/*
 * Display disk partitions and status of the winnie partition table.
 *		Version 86/2.0		6/5/84
 */
#include	"xtblk0.h"

#define	DEVICE	"/dev/w0.phy"

struct xp xp;

main(){
	register int i, j;

	if( (i = open(DEVICE,2)) < 0 ){
		printf("Cannot open `%s' partition table.\n",DEVICE);
		exit(1);
	}
	if( read(i,&xp, 512) != 512 ){
		printf("Cannot read partition table.\n");
		exit(1);
	}
	if( xp.xp_sig != XP_SIG ){
		printf("Partition table has invalid signature.\n");
		exit(1);
	}
printf("\nPartition   Status       Type       Start   End   Size(blk)\n");
	for( j = 0; j < 4; j++ ){
		printf("    %d         %c     ",j+1,xp.xp_tab[j].xp_boot==XP_BOOT ?
			'A' : 'N' );
		switch( xp.xp_tab[j].xp_sys ){
		case XP_DOS:
			printf("     DOS      ");
			break;
		case XP_SYS:
			printf(" VENIX system ");
			break;
		case XP_TMP:
			printf("  VENIX temp  ");
			break;
		case XP_USR:
			printf("  VENIX user  ");
			break;
		case 0:
			printf("    Unused    ");
			break;
		default:
			printf("    Unknown   ");
		}
		printf(" %5d  ",xp.xp_tab[j].xp_s_c +
			((xp.xp_tab[j].xp_s_s&0300)<<2) );
		printf("%5d  ",xp.xp_tab[j].xp_e_c +
			((xp.xp_tab[j].xp_e_s&0300)<<2) );
		printf("%8D\n",xp.xp_tab[j].xp_size);
	}
	printf("\n");
}
