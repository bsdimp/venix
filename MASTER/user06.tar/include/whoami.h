#define sysname "VENIX/86"
