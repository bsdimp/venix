char myname[] = "misha";
