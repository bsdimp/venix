struct fblk
{
	int    	df_nfree;
	unsigned	df_free[100];
};
