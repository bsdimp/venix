typedef int jmp_buf[6];
