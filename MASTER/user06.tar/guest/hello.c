/*
 * Standard first program.
 */

main()
{
	printf("Hello world!\n");
}

