#define INCH 240
/*
DIABLO HTYPE 1620
nroff driving tables
width and code tables
this is identical to tab450.c, except that
special pseudo bold-on/off codes have been
added, to be filtered through a bold program,
and a couple of characters are different.
*/

struct {
	int bset;
	int breset;
	int Hor;
	int Vert;
	int Newline;
	int Char;
	int Em;
	int Halfline;
	int Adj;
	char *twinit;
	char *twrest;
	char *twnl;
	char *hlr;
	char *hlf;
	char *flr;
	char *bdon;
	char *bdoff;
	char *ploton;
	char *plotoff;
	char *up;
	char *down;
	char *right;
	char *left;
	char *codetab[256-32];
	int zzz;
	} t {
/*bset*/        040,            /* raw mode */
/*breset*/	0177420,
/*Hor*/		INCH/60,
/*Vert*/	INCH/48,
/*Newline*/	INCH/6,
/*Char*/	INCH/12,
/*Em*/		INCH/12,
/*Halfline*/	INCH/12,
/*Adj*/		INCH/12,
/*twinit*/	"\0334\r",
/*twrest*/      "\0334\r",
/*twnl*/	"\015\n",
/*hlr*/		"\033D",
/*hlf*/		"\033U",
/*flr*/		"\033\n",
/*bdon*/        "\001",         /* pseudo-code for filter purposes */
/*bdoff*/       "\002",         /*   "     "    "     "       "    */
/*ploton*/	"\0333",
/*plotoff*/	"\0334",
/*up*/		"\033\n",
/*down*/	"\n",
/*right*/	" ",
/*left*/	"\b",
/*codetab take from code.300, with some improvements */
"\001 ",	/*space*/
"\001!",	/*!*/
"\001\"",	/*"*/
"\001#",	/*#*/
"\001$",	/*$*/
"\001%",	/*%*/
"\001&",	/*&*/
"\001'",        /*' close*/
"\001(",	/*(*/
"\001)",	/*)*/
"\001*",	/***/
"\001+",	/*+*/
"\001,",	/*,*/
"\001-",	/*- hyphen*/
"\001.",	/*.*/
"\001/",	/*/*/
"\2010",	/*0*/
"\2011",	/*1*/
"\2012",	/*2*/
"\2013",	/*3*/
"\2014",	/*4*/
"\2015",	/*5*/
"\2016",	/*6*/
"\2017",	/*7*/
"\2018",	/*8*/
"\2019",	/*9*/
"\001:",	/*:*/
"\001;",	/*;*/
"\001<",	/*<*/
"\001=",	/*=*/
"\001>",	/*>*/
"\001?",	/*?*/
"\001@",	/*@*/
"\201A",	/*A*/
"\201B",	/*B*/
"\201C",	/*C*/
"\201D",	/*D*/
"\201E",	/*E*/
"\201F",	/*F*/
"\201G",	/*G*/
"\201H",	/*H*/
"\201I",	/*I*/
"\201J",	/*J*/
"\201K",	/*K*/
"\201L",	/*L*/
"\201M",	/*M*/
"\201N",	/*N*/
"\201O",	/*O*/
"\201P",	/*P*/
"\201Q",	/*Q*/
"\201R",	/*R*/
"\201S",	/*S*/
"\201T",	/*T*/
"\201U",	/*U*/
"\201V",	/*V*/
"\201W",	/*W*/
"\201X",	/*X*/
"\201Y",	/*Y*/
"\201Z",	/*Z*/
"\001[",	/*[*/
"\001\\",	/*\*/
"\001]",	/*]*/
"\001^",	/*^*/
"\001_",	/*_ dash*/
"\001'",        /*` open (looks lousy on diablo--changed to a ')*/
"\201a",        /*a*/
"\201b",	/*b*/
"\201c",	/*c*/
"\201d",	/*d*/
"\201e",	/*e*/
"\201f",	/*f*/
"\201g",	/*g*/
"\201h",	/*h*/
"\201i",	/*i*/
"\201j",	/*j*/
"\201k",	/*k*/
"\201l",	/*l*/
"\201m",	/*m*/
"\201n",	/*n*/
"\201o",	/*o*/
"\201p",	/*p*/
"\201q",	/*q*/
"\201r",	/*r*/
"\201s",	/*s*/
"\201t",	/*t*/
"\201u",	/*u*/
"\201v",	/*v*/
"\201w",	/*w*/
"\201x",	/*x*/
"\201y",	/*y*/
"\201z",	/*z*/
"\001{",	/*{*/
"\001|",	/*|*/
"\001}",	/*}*/
"\001~",	/*~*/
"\000\0",	/*narrow sp*/
"\001-",	 /*hyphen*/
"\001\200o\301*\341",   /* bullet */
/*"\001\200o\241\344.\201.\242\301.\201.\201.\241\301.\302\201",  /* bullet */
/* "\001o\b+",       old bullet*/
/* "\002\201<\204>",   /* square */
"\001\344. . . .\243\301. . . .\243\301. . . .\243\301",   /* square */
/* "\002\[]",        old square*/
"\001-",	 /*3/4 em*/
"\001_",	 /*rule*/
"\0031/4",	 /*1/4*/
"\0031/2",	 /*1/2*/
"\0033/4",	 /*3/4*/
"\001-",	 /*minus*/
"\202fi",	 /*fi*/
"\202fl",	 /*fl*/
"\202ff",	 /*ff*/
"\203ffi",	 /*ffi*/
"\203ffl",	 /*ffl*/
"\001\344o\304",	 /*degree*/
"\001|\b-",	 /*dagger*/
"\001l\bo",	/* section*/
"\001'",	 /*foot mark*/
"\001'",	 /*acute accent*/
"\001`",	 /*grave accent*/
"\001_",	 /*underrule*/
"\001/",	 /*slash (longer)*/
"\000\0",	/*half narrow space*/
"\001 ",	/*unpaddable space*/
"\001\241c\202(\241", /*alpha*/
"\001\200B\242\302\|\202\342", /*beta*/
"\001\200)\201/\241", /*gamma*/
"\001\200o\342<\302", /*delta*/
"\001<\b-", /*epsilon*/
"\001\200c\201\301,\241\343<\302", /*zeta*/
"\001\200n\202\302|\242\342", /*eta*/
"\001O\b-", /*theta*/
"\001i",	 /*iota*/
"\001k",	 /*kappa*/
"\001\200\\\304\241'\301\241'\345\202", /*lambda*/
"\001\200u\242,\202", /*mu*/
"\001\241(\203/\242", /*nu*/
"\001\200c\201\301,\241\343c\241\301`\201\301", /*xi*/
"\001o",	 /*omicron*/
"\001\303'\203'\243\341'\203'\243\341~\201~\201~\201~\341\243",/*pi*/
/* "\001\341-\303\"\301\"\343",  old pi*/
"\001\200o\242\302|\342\202", /*rho*/
"\001\200o\301\202~\341\242", /*sigma*/
"\001\200t\301\202~\243~\201\341", /*tau*/
"\001v",	 /*upsilon*/
"\001o\b/", /*phi*/
"\001x",	 /*chi*/
"\001\200/-\302\202'\244'\202\342", /*psi*/
"\001\241u\203u\242", /*omega*/
"\001\242|\202\343-\303\202`\242", /*Gamma*/
"\001\242/\303-\204-\343\\\242", /*Delta*/
"\001O\b=", /*Theta*/
"\001\242/\204\\\242", /*Lambda*/
"\001\\b/",	 /*Xi*/
"\001\242[]\204[]\242\343-\303", /*Pi*/
"\001\200>\304-\346-\302", /*Sigma*/
"\000\0",	 /**/
"\001Y",	 /*Upsilon*/
"\001o\b[\b]", /*Phi*/
"\001\200[]-\302\202'\244`\202\342", /*Psi*/
"\001\200O\302\241-\202-\241\342", /*Omega*/
"\000\0",	 /*square root*/
"\000\0",	 /*terminal sigma*/
"\000\0",	 /*root en*/
"\001>\b_",	 /*>=*/
"\001<\b_",	 /*<=*/
"\001=\b_",	 /*identically equal*/
"\001-",	 /*equation minus*/
"\001=\b~",	 /*approx =*/
"\001~",         /*approximates*/
"\001=\b/",	 /*not equal*/
"\002--\b>",     /*right arrow*/
"\002<\b--",     /*left arrow*/
"\001|\b^",	 /*up arrow*/
"\001|\bv",      /*down arrow*/
"\001=",	 /*equation equal*/
"\001x",	 /*multiply*/
"\001/",	 /*divide*/
"\001+\b_",	 /*plus-minus*/
"\001U",	 /*cup (union)*/
"\000\0",	 /*cap (intersection)*/
"\000\0",	 /*subset of*/
"\000\0",	 /*superset of*/
"\000\0",	 /*improper subset*/
"\000\0",	 /* improper superset*/
"\002oo",	 /*infinity*/
"\001\200o\201\301`\241\341`\241\341`\201\301", /*partial derivative*/
"\001\242\\\343-\204-\303/\242", /*gradient*/
"\001\200-\202\341,\301\242", /*not*/
"\001\200|'\202`\243\306'\241`\202\346",	/*integral sign*/
"\000\0",	 /*proportional to*/
"\001O\b/",      /*empty set*/
"\001\C\b-",     /*member of*/
"\001+",	 /*equation plus*/
"\001r\bO",	 /*registered*/
"\001c\bO",	 /*copyright*/
"\001|",	 /*box rule */
"\001c\b/",	 /*cent sign*/
"\001|\b=",	 /*dbl dagger*/
"\002=>",	 /*right hand*/
"\002<=",	 /*left hand*/
"\001*",	 /*math * */
"\000\0",	 /*bell system sign*/
"\001|",	 /*or (was star)*/
"\001O",	 /*circle*/
"\001|",	 /*left top (of big curly)*/
"\001|",	 /*left bottom*/
"\001|",	 /*right top*/
"\001|",	 /*right bot*/
"\001|",	 /*left center of big curly bracket*/
"\001|",	 /*right center of big curly bracket*/
"\001|",	/*bold vertical*/
"\001|",	/*left floor (left bot of big sq bract)*/
"\001|",	/*right floor (rb of ")*/
"\001|",	/*left ceiling (lt of ")*/
"\001|"};	/*right ceiling (rt of ")*/
